import os
import sys
from logging.config import fileConfig

# Add the project root to the Python path so we can import our modules
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy import engine_from_config, pool

from alembic import context
from app.infrastructure.core.config import Config
from app.infrastructure.db.orm import Base

# this is the Alembic Config object, which provides
# access to the values within the .ini file in use.
config = context.config

# Interpret the config file for Python logging.
# This line sets up loggers basically.
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Set the target metadata to our Base
target_metadata = Base.metadata

# other values from the config, defined by the needs of env.py,
# can be acquired:
# my_important_option = config.get_main_option("my_important_option")
# ... etc.


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode.

    This configures the context with just a URL
    and not an Engine, though an Engine is acceptable
    here as well.  By skipping the Engine creation
    we don't even need a DBAPI to be available.

    Calls to context.execute() here emit the given string to the
    script output.

    """
    # Use Config if sqlalchemy.url is not set in the config
    url = config.get_main_option("sqlalchemy.url")
    if not url:
        db_config = Config()
        url = db_config.database_url

    context.configure(
        url=url,
        target_metadata=target_metadata,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode.

    In this scenario we need to create an Engine
    and associate a connection with the context.

    """
    # Use Config if sqlalchemy.url is not set in the config
    sqlalchemy_url = config.get_main_option("sqlalchemy.url")
    if not sqlalchemy_url:
        db_config = Config()
        config.set_main_option("sqlalchemy.url", db_config.database_url)

    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)

        with context.begin_transaction():
            context.run_migrations()


# Use offline mode for autogenerate to avoid needing a DB connection
if context.is_offline_mode() or os.environ.get("ALEMBIC_CMD") == "revision":
    run_migrations_offline()
else:
    run_migrations_online()
