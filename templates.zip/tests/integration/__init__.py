"""Integration tests package initialization."""
